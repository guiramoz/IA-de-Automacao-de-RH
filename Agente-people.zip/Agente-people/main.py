import os
import json
import streamlit as st
from dotenv import load_dotenv 
from openai import OpenAI
from google_tools import (agendar_entrevista_com_meet, registrar_cadidato)

st.set_page_config(
    page_title="Agente de RH", 
    page_icon="🤖",   
    layout="wide"
)

#carregar as variaveis de ambiente 
load_dotenv()

client = OpenAI(api_key=os.environ.get("HUGGINGFACE_API_KEY"),
                base_url="https://router.huggingaface.co/v1") 
#nesse projeto, o cliente aponta pro router api da hugging face
PLANILHA_ID = "1g2P0Xf_6sUufj_PS6MLrNDvGmrhP403A0JAJUC92r6I"

def executar_agente(mensagem_usuario):

    """
    Receba uma mensagem em linguagem natural,
    envie essa mensagem para o modelo de IA,
    e execute automaticamente as funções nescessárias.
    """
    #lista as ferramentas que a IA vai utilizar

    ferramentas = [
        {
        "type":"function",
        "function":{
            "name":"agendar_entrevista_com_meet",
            "description":"Agenda uma entrevista no Google Meet e envia e-mail",
            "parameters":{
                "type":"object",
                "properties":{
                    "nome_candidato":{"type":"string"},
                    "email_candidato":{"type":"string"},
                    "data_hora_inicio":{"type":"string","description" :"Formato ISO 8601"},
                    "data_hora_fim":{"type":"string","descpription": "Formato ISO 8601"}
                },
            }
        }
        }
    ]