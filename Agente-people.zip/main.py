import os
import json
import re
import streamlit as st
from dotenv import load_dotenv
from openai import OpenAI
from google_tools import agendar_entrevista_com_meet, registrar_candidato_planilha

# ------------------------------------------------------------------------------
# 1. CONFIGURAÇÃO DA PÁGINA E CARREGAMENTO DE VARIÁVEIS
# ------------------------------------------------------------------------------
st.set_page_config(
    page_title="Agente de RH - IA",
    page_icon="🤖",
    layout="wide"
)

load_dotenv()

# Instância do Cliente OpenAI apontando para o Router da Hugging Face
client = OpenAI(
    api_key=os.environ.get("HUGGINGFACE_API_KEY"),
    base_url="https://router.huggingface.co/v1"
)

# Modelo configurável pelo ambiente. Mantém um fallback compatible com o router.
MODELO_GROQ = os.environ.get("HF_MODEL") or os.environ.get("MODEL_NAME") or "openai/gpt-oss-20b"

# ATENÇÃO: Substitua pelo ID da sua planilha do Google Sheets
PLANILHA_ID = "1g2P0Xf_6sUufj_PS6MLrNDvGmrhP403A0JAJUC92r6I"

# ------------------------------------------------------------------------------
# 2. FUNÇÃO PRINCIPAL DO AGENTE DE IA
# ------------------------------------------------------------------------------
def extrair_dados_planilha_do_prompt(mensagem_usuario):
    vaga = None
    status = None

    padroes_vaga = [
        r"vaga\s+(?:e|é|de|para|como)\s+['\"]?([^'\".,\n]+)",
        r"para\s+a\s+vaga\s+(?:de\s+)?['\"]?([^'\".,\n]+)",
        r"cargo\s+(?:de\s+)?['\"]?([^'\".,\n]+)",
    ]
    for padrao in padroes_vaga:
        match = re.search(padrao, mensagem_usuario, flags=re.IGNORECASE)
        if match:
            vaga = match.group(1).strip()
            break

    padroes_status = [
        r"com\s+o\s+status\s+['\"]?([^'\".,\n]+)",
        r"status\s+['\"]?([^'\".,\n]+)",
    ]
    for padrao in padroes_status:
        match = re.search(padrao, mensagem_usuario, flags=re.IGNORECASE)
        if match:
            status = match.group(1).strip()
            break

    return {
        "vaga": vaga or "Não informada",
        "status": status or "Agendado",
    }


def executar_agente_rh(mensagem_usuario):
    """Processa o prompt do usuário via LLM e executa as ferramentas do Google Workspace."""

    dados_planilha_prompt = extrair_dados_planilha_do_prompt(mensagem_usuario)
    prompt_lower = mensagem_usuario.lower()
    pede_planilha = any(token in prompt_lower for token in (
        "planilha", "cadastrar", "cadastro", "registrar", "salvar", "sheet"
    ))
    pede_agendamento = any(token in prompt_lower for token in (
        "agendar", "entrevista", "reunião", "meet", "calendario", "marque"
    ))
    
    ferramentas = [
        {
            "type": "function",
            "function": {
                "name": "agendar_entrevista_com_meet",
                "description": "Agenda uma entrevista no Google Meet e envia e-mail de convite.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "nome_candidato": {"type": "string"},
                        "email_candidato": {"type": "string"},
                        "data_hora_inicio": {"type": "string", "description": "ISO 8601 ex: 2026-07-25T14:00:00"},
                        "data_hora_fim": {"type": "string", "description": "ISO 8601 ex: 2026-07-25T15:00:00"}
                    },
                    "required": ["nome_candidato", "email_candidato", "data_hora_inicio", "data_hora_fim"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "registrar_candidato_planilha",
                "description": "Salva os dados do candidato no Google Sheets. Sempre que o usuário pedir para cadastrar, registrar ou salvar na planilha, chame esta função.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "nome": {"type": "string", "description": "Nome do candidato"},
                        "email": {"type": "string", "description": "E-mail do candidato"},
                        "vaga": {"type": "string", "description": "Nome da vaga. Se não informada, use 'Não informada'"},
                        "status": {"type": "string", "description": "Status da candidatura. Ex: 'Agendado', 'Em Análise'"}
                    },
                    "required": ["nome", "email"]
                }
            }
        }
    ]

    try:
        resposta = client.chat.completions.create(
            model=MODELO_GROQ,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "Você é um assistente de RH altamente especializado.\n\n"
                        "REGRAS DE EXECUÇÃO:\n"
                        "1. Se o usuário solicitar agendar reunião E registrar na planilha, você DEVE disparar AMBAS as ferramentas simultaneamente.\n"
                        "2. Caso o usuário não informe a vaga para a planilha, preencha automaticamente com 'Não informada'.\n"
                        "3. Caso o usuário não informe o status, preencha com 'Agendado' (se houver reunião) ou 'Cadastrado'."
                    )
                },
                {"role": "user", "content": mensagem_usuario}
            ],
            tools=ferramentas,
            tool_choice="auto"
        )

        mensagem_assistente = resposta.choices[0].message
        resultados = []
        executou_agendamento = False
        executou_planilha = False
        dados_candidato_agendamento = None

        if mensagem_assistente.tool_calls:
            for tool_call in mensagem_assistente.tool_calls:
                nome_funcao = tool_call.function.name
                argumentos = json.loads(tool_call.function.arguments)

                if nome_funcao == "agendar_entrevista_com_meet":
                    res = agendar_entrevista_com_meet(
                        argumentos["nome_candidato"], 
                        argumentos["email_candidato"],
                        argumentos["data_hora_inicio"],
                        argumentos["data_hora_fim"]
                    )
                    resultados.append(("calendar", res))
                    executou_agendamento = True
                    dados_candidato_agendamento = {
                        "nome": argumentos["nome_candidato"],
                        "email": argumentos["email_candidato"]
                    }

                elif nome_funcao == "registrar_candidato_planilha":
                    vaga = argumentos.get("vaga") or dados_planilha_prompt["vaga"]
                    status = argumentos.get("status") or dados_planilha_prompt["status"]
                    if vaga.strip().lower() in ("não informada", "nao informada"):
                        vaga = dados_planilha_prompt["vaga"]
                    if status.strip().lower() in ("não informado", "nao informado", "não informada", "nao informada"):
                        status = dados_planilha_prompt["status"]
                    res = registrar_candidato_planilha(
                        PLANILHA_ID,
                        argumentos["nome"], 
                        argumentos["email"],
                        vaga,
                        status
                    )
                    resultados.append(("sheets", res))
                    executou_planilha = True

            # Fallback de consistência do backend: se a intenção do prompt pede
            # planilha e o calendário já foi executado, mas a LLM não emitiu esse
            # tool_call por limitação de parallel tool-calling, registramos o candidato
            # também na planilha usando os dados do evento gerado.
            if pede_planilha and executou_agendamento and not executou_planilha and dados_candidato_agendamento:
                vaga = dados_planilha_prompt["vaga"]
                status = dados_planilha_prompt["status"]
                res = registrar_candidato_planilha(
                    PLANILHA_ID,
                    dados_candidato_agendamento["nome"],
                    dados_candidato_agendamento["email"],
                    vaga,
                    status
                )
                resultados.append(("sheets", res))

            return resultados
        else:
            return [("texto", mensagem_assistente.content)]

    except Exception as e:
        return [("erro", str(e))]

# ------------------------------------------------------------------------------
# 3. CONSTRUÇÃO DA INTERFACE GRÁFICA (STREAMLIT)
# ------------------------------------------------------------------------------

# --- BARRA LATERAL (Sidebar) ---
with st.sidebar:
    st.image("https://upload.wikimedia.org/wikipedia/commons/a/a8/Google_Workspace_icon_%282020%29.svg", width=60)
    st.title("Painel do Sistema")
    st.markdown("---")
    
    st.subheader("⚙️ Status do Ambiente")
    if os.environ.get("HUGGINGFACE_API_KEY"):
        st.success("Hugging Face API: Conectado")
    else:
        st.error("Hugging Face API: Chave não encontrada")

    if os.path.exists("credentials.json"):
        st.success("Google Credentials: Ok")
    else:
        st.warning("Google Credentials: Ausente")

    st.markdown("---")
    st.info(f"💡 **Modelo em uso:** `{MODELO_GROQ}` via Hugging Face Router.")

# --- CONTEÚDO PRINCIPAL ---
st.title("🤖 Agente de RH Inteligente")
st.subheader("Agendamento de Entrevistas & Gestão de Candidatos")
st.markdown("---")

# Controle de estado para sugestões de prompt
if "prompt_input" not in st.session_state:
    st.session_state.prompt_input = ""

def aplicar_sugestao(texto):
    st.session_state.prompt_input = texto

# --- SUGESTÕES DE PROMPT (Cards/Botões) ---
st.markdown("### 💡 Sugestões Rápidas (Clique para testar):")

col1, col2, col3 = st.columns(3)

with col1:
    sugestao_1 = "Marque uma entrevista com a candidata Ana Souza (ana.souza@gmail.com) para amanhã das 14:00 às 15:00 (ISO: 2026-07-25T14:00:00 até 2026-07-25T15:00:00). A vaga é 'Desenvolvedora Frontend' e registre na planilha com o status 'Agendado'."
    if st.button("📅 Agendar Reunião + Planilha", use_container_width=True):
        aplicar_sugestao(sugestao_1)

with col2:
    sugestao_2 = "Registre o candidato Marcos Oliveira (marcos.o@email.com) na planilha para a vaga de 'Engenheiro de Dados' com o status 'Em Análise'."
    if st.button("📊 Apenas Cadastrar na Planilha", use_container_width=True):
        aplicar_sugestao(sugestao_2)

with col3:
    sugestao_3 = "Agende uma conversa rápida de 30 minutos com Lucas Santos (lucas.santos@email.com) para amanhã às 10h (ISO: 2026-07-25T10:00:00 até 2026-07-25T10:30:00)."
    if st.button("✉️ Apenas Criar Call no Meet", use_container_width=True):
        aplicar_sugestao(sugestao_3)

st.markdown("<br>", unsafe_allow_html=True)

# --- ÁREA DE TEXTO E BOTÃO DE EXECUÇÃO ---
prompt_usuario = st.text_area(
    "Digite sua instrução para o Agente:",
    value=st.session_state.prompt_input,
    height=120,
    placeholder="Ex: Agende uma entrevista para o candidato..."
)

if st.button("🚀 Processar Solicitação", type="primary", use_container_width=True):
    if not prompt_usuario.strip():
        st.warning("Por favor, digite um comando ou selecione uma das sugestões acima.")
    else:
        with st.spinner("🤖 O Agente está analisando a instrução e executando as ações..."):
            retorno = executar_agente_rh(prompt_usuario)

        st.markdown("---")
        st.markdown("### 📋 Resultado do Processamento:")

        for tipo, conteudo in retorno:
            if tipo == "calendar":
                st.success(f"**Google Agenda & Meet:** {conteudo}")
            elif tipo == "sheets":
                st.info(f"**Google Sheets:** {conteudo}")
            elif tipo == "texto":
                st.write(conteudo)
            elif tipo == "erro":
                st.error(f"**Erro de Processamento:** {conteudo}")
