#dependências do projeto 
import os
import uuid
import base64
from email.message import EmailMessage
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from google.auth.transport.requests import Request

#lista de permissões (scopes) necessárias para acessar a API do Google Drive)

SCOPES = [
    #permissão pra criar/editar eventos na agenda 
    'https://www.googleapis.com/auth/calendar.events',

    #permissão pra ler/editar planilhas do Google Sheets
    'https://www.googleapis.com/auth/spreadsheets',

    #permissao para enviar e-mail com os detalhes da entrevista
    'https://www.googleapis.com/auth/gmail.send'
]

#função pra autentificar o usuario na conta do Google 
def extrair_link_meet(evento_criado):
    link_meet = evento_criado.get('hangoutLink')
    if link_meet:
        return link_meet

    conference_data = evento_criado.get('conferenceData', {})
    for entry_point in conference_data.get('entryPoints', []):
        if entry_point.get('entryPointType') == 'video' and entry_point.get('uri'):
            return entry_point['uri']

    return None


def enviar_email_entrevista(email_candidato, nome_candidato, data_hora_inicio, data_hora_fim, link_meet, link_evento=None):
    creds = autenticar_google()
    service = build('gmail', 'v1', credentials=creds)

    assunto = f"Entrevista de RH - {nome_candidato}"
    corpo = (
        f"Ola, {nome_candidato}!\n\n"
        "Sua entrevista de RH foi agendada com sucesso.\n\n"
        f"Inicio: {data_hora_inicio}\n"
        f"Fim: {data_hora_fim}\n"
        f"Link do Google Meet: {link_meet or 'Link nao disponivel no momento'}\n"
        f"Link do evento: {link_evento or 'Link do evento nao disponivel no momento'}\n\n"
        "Atenciosamente,\n"
        "Time de People"
    )

    mensagem = EmailMessage()
    mensagem.set_content(corpo)
    mensagem['To'] = email_candidato
    mensagem['Subject'] = assunto

    raw_message = base64.urlsafe_b64encode(mensagem.as_bytes()).decode()
    service.users().messages().send(
        userId='me',
        body={'raw': raw_message}
    ).execute()


def autenticar_google():

    #variável para armazenar as credenciais do usuário
    creds = None

    #verifica se já existe um arquivo de autentificação salvo 
    if os.path.exists('token.json'):

        #carrega as credenciais armazenadas anteriormente
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    
    #se as credenciais não existirem ou estiverem invalidas
    if not creds or not creds.valid:

        #se as credenciais estiverem expiradas, tenta renová-las
        if creds and creds.expired and creds.refresh_token:


            creds.refresh(Request())
        
        #se não houver credenciais válidas, inicia o fluxo de autenticação
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)

            #abre navegador para usuário fazer login
            creds = flow.run_local_server(port=8080)

        #salva novas credeciais pra reutilizar
        
        #salva as credenciais para a próxima execução
        with open('token.json', 'w') as token:
            token.write(creds.to_json()) #escreve como formato JSON

    return creds #retorna as credenciais novas autentificadas 

#função para criar uma entrevista no google agenda
def agendar_entrevista_com_meet(
    nome_candidato,
    email_candidato,
    data_hora_inicio,
    data_hora_fim
):

    creds = autenticar_google() #obtem as credencias do usuario
    service = build('calendar', 'v3', credentials=creds) #cria o cliente para acessar da API do Google Calendar

    #dicionario contendo as informações do evento
    evento = {
        'summary': f'Entrevista de RH - {nome_candidato}', #titulo
        'description': f'Entrevista de RH com o time de people. O link do meet está anexado ao e-mail.',   #descrição
        'start': {'dateTime':data_hora_inicio, 'timeZone':'America/Sao_Paulo'}, #data e hora de inicio
        'end': {'dateTime':data_hora_fim, 'timeZone':'America/Sao_Paulo'}, #data e hora de fim
        'attendees':[{'email': email_candidato}], #lista de participantes
        'conferenceData':{
            'createRequest':{
                'requestId':f"{uuid.uuid4()}", #gera id unico
                'conferenceSolutionKey':{
                    'type':'hangoutsMeet' #tipo de conferência (Google Meet)
                }
            }
        }
    }

    #envia o evento para o google agenda
    evento_criado = service.events().insert(
        calendarId='primary', #id do calendario (padrão)
        body=evento, #informações do evento
        conferenceDataVersion=1, #versão da conferência
        sendUpdates='all'
    ).execute()

    link_meet = extrair_link_meet(evento_criado) #pega o link do meet do evento criado
    link_evento = evento_criado.get('htmlLink')
    email_enviado = True
    erro_email = None
    try:
        enviar_email_entrevista(
            email_candidato,
            nome_candidato,
            data_hora_inicio,
            data_hora_fim,
            link_meet,
            link_evento
        )
    except Exception as e:
        email_enviado = False
        erro_email = str(e)

    if link_meet:
        if email_enviado:
            return f"Sucesso! Entrevista agendada e e-mail enviado. Link do Meet: {link_meet}"
        return f"Entrevista agendada. Link do Meet: {link_meet}. Falha ao enviar e-mail: {erro_email}"

    if email_enviado:
        return f"Sucesso! Entrevista agendada e e-mail enviado. Link do Meet nao retornado pelo Google Calendar. Link do evento: {link_evento}"
    return f"Entrevista agendada, mas o Meet nao foi retornado. Link do evento: {link_evento}. Falha ao enviar e-mail: {erro_email}"

#função responsável por registrar o candidato na planilha
def registrar_candidato_planilha(id_planilha, nome, email, vaga, status):
    creds = autenticar_google() #obtem as credenciais do google
    service = build('sheets', 'v4', credentials=creds)
    valores = [(nome,email,vaga,status)] 

    body={
        'values':valores
    } #corpo da requisição esperado para API do GSheets

    service.spreadsheets().values().append(
        spreadsheetId=id_planilha, #id da planilha
        range='Página1!A:D', #intervalo de células onde os dados serão inseridos
        valueInputOption = 'USER_ENTERED', #permite que o
        body=body
    ).execute()

# Compatibilidade com versões antigas que ainda chamavam o nome antigo.
registrar_candidato = registrar_candidato_planilha
